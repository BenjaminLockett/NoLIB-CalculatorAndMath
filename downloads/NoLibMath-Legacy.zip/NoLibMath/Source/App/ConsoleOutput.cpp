#include "App/ConsoleOutput.hpp"

#include <iostream>

#include "NoLib/Text/StringStreamAdapters.hpp"

namespace App
{
    void printError(const char* message_CharPtr_Var)
    {
        std::cout << message_CharPtr_Var << '\n';
    }

    void printRealResult(const char* label_CharPtr_Var, NoLib::Real value_Real_Var, NoLib::UInt decimals_UInt_Var)
    {
        std::cout << label_CharPtr_Var << NoLib::realToString(value_Real_Var, decimals_UInt_Var) << '\n';
    }

    void printScientificResult(const char* label_CharPtr_Var, const NoLib::ScientificNumber& value_Scientific_Var)
    {
        std::cout << label_CharPtr_Var << value_Scientific_Var.value_Real_Var << " x 10^";

        if (value_Scientific_Var.negativePower_Bool_Var)
        {
            std::cout << '-';
        }

        std::cout << value_Scientific_Var.power_ULong_Var << '\n';
    }

    // Prints from the highest power downward, matching normal written order.
    void printPolynomial(const NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var>& polynomial_Polynomial_Var)
    {
        for (NoLib::UInt index_UInt_Var = polynomial_Polynomial_Var.degree_UInt_Var + 1; index_UInt_Var > 0; --index_UInt_Var)
        {
            NoLib::UInt power_UInt_Var = index_UInt_Var - 1;
            NoLib::Real coefficient_Real_Var = polynomial_Polynomial_Var.coefficients_RealArray_Var[power_UInt_Var];

            if (power_UInt_Var != polynomial_Polynomial_Var.degree_UInt_Var && coefficient_Real_Var >= 0.0L)
            {
                std::cout << "+ ";
            }

            std::cout << NoLib::realToString(coefficient_Real_Var, CoefficientDecimals_UInt_Var) << "x^" << power_UInt_Var << ' ';
        }

        std::cout << '\n';
    }
}
