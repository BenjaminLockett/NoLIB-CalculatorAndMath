#include "App/Commands/DecimalPowerCommand.hpp"

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "NoLib/Scalar/Powers.hpp"

namespace App
{
    // A finite Real result is preferred. A positive base that overflows Real is
    // retried in scientific form; a negative base is rejected and redirected.
    void runDecimalPower()
    {
        NoLib::Real base_Real_Var = 0.0L;
        NoLib::Real exponent_Real_Var = 0.0L;

        if (!readRealPrompt("Real base: ", base_Real_Var) || !readRealPrompt("Real exponent: ", exponent_Real_Var))
        {
            return;
        }

        NoLib::Real result_Real_Var = 0.0L;

        if (NoLib::realPower(base_Real_Var, exponent_Real_Var, result_Real_Var))
        {
            printRealResult("Approximate result: ", result_Real_Var, ResultDecimals_UInt_Var);
            return;
        }

        NoLib::ScientificNumber result_Scientific_Var;

        if (base_Real_Var > 0.0L && NoLib::scientificRealPower(base_Real_Var, exponent_Real_Var, result_Scientific_Var))
        {
            printScientificResult("Approximate scientific result: ", result_Scientific_Var);
            return;
        }

        printError("No finite real result was produced. Use rational or complex power for a negative base.");
    }
}
