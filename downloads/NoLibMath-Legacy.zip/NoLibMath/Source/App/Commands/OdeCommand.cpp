#include "App/Commands/OdeCommand.hpp"

#include <iostream>

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "NoLib/Numerical/Ode.hpp"

namespace App
{
    namespace
    {
        // The worked example built into the menu: dy/dx = x + y.
        NoLib::Real sampleDerivative(NoLib::Real x_Real_Var, NoLib::Real y_Real_Var)
        {
            return x_Real_Var + y_Real_Var;
        }
    }

    void runOde()
    {
        NoLib::Real startX_Real_Var = 0.0L;
        NoLib::Real startY_Real_Var = 0.0L;
        NoLib::Real targetX_Real_Var = 0.0L;
        NoLib::ULong steps_ULong_Var = 0;

        std::cout << "Example equation: dy/dx = x + y\n";

        if (!readRealPrompt("Starting x: ", startX_Real_Var) || !readRealPrompt("Starting y: ", startY_Real_Var) || !readRealPrompt("Target x: ", targetX_Real_Var))
        {
            return;
        }

        if (!readUnsignedPrompt("Euler steps: ", steps_ULong_Var) || steps_ULong_Var > MaximumEulerSteps_ULong_Var)
        {
            printError("Step count is outside this build's range.");
            return;
        }

        NoLib::Real result_Real_Var = NoLib::solveEuler(sampleDerivative, startX_Real_Var, startY_Real_Var, targetX_Real_Var, static_cast<NoLib::UInt>(steps_ULong_Var));

        printRealResult("Euler approximation: ", result_Real_Var, ResultDecimals_UInt_Var);
    }
}
