#include "App/Commands/ComplexPowerCommand.hpp"

#include <iostream>

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "NoLib/Complex/ComplexElementary.hpp"
#include "NoLib/Complex/ComplexFormatting.hpp"
#include "NoLib/Text/StringStreamAdapters.hpp"

namespace App
{
    // Only the principal value is reported; the full multivalued family is not enumerated.
    void runComplexPower()
    {
        NoLib::ComplexNumber base_Complex_Var;
        NoLib::ComplexNumber exponent_Complex_Var;

        if (!readRealPrompt("Base real part: ", base_Complex_Var.real_Real_Var) || !readRealPrompt("Base imaginary part: ", base_Complex_Var.imaginary_Real_Var))
        {
            return;
        }

        if (!readRealPrompt("Exponent real part: ", exponent_Complex_Var.real_Real_Var) || !readRealPrompt("Exponent imaginary part: ", exponent_Complex_Var.imaginary_Real_Var))
        {
            return;
        }

        NoLib::ComplexNumber result_Complex_Var;

        if (!NoLib::complexPower(base_Complex_Var, exponent_Complex_Var, result_Complex_Var))
        {
            printError("The complex power is undefined or overflowed.");
            return;
        }

        std::cout << "Principal-value result: " << NoLib::complexToString(result_Complex_Var, ComplexDecimals_UInt_Var) << '\n';
    }
}
