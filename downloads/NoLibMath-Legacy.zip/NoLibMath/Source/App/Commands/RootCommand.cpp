#include "App/Commands/RootCommand.hpp"

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "NoLib/Scalar/Powers.hpp"

namespace App
{
    void runRoot()
    {
        NoLib::Real value_Real_Var = 0.0L;
        NoLib::ULong degree_ULong_Var = 0;

        if (!readRealPrompt("Number: ", value_Real_Var) || !readUnsignedPrompt("Root degree (2 = square root, 3 = cube root): ", degree_ULong_Var))
        {
            return;
        }

        NoLib::Real result_Real_Var = 0.0L;

        if (!NoLib::nthRoot(value_Real_Var, degree_ULong_Var, result_Real_Var))
        {
            printError("That root has no real result.");
            return;
        }

        printRealResult("Approximate root: ", result_Real_Var, ResultDecimals_UInt_Var);
    }
}
