#include "App/Commands/PiCommand.hpp"

#include "App/ConsoleOutput.hpp"
#include "NoLib/Scalar/Constants.hpp"

namespace App
{
    void runPi()
    {
        printRealResult("Pi approximation: ", NoLib::piApproximation(), ConstantDecimals_UInt_Var);
    }
}
