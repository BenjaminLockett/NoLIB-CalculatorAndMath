#include "App/Commands/IntegerPowerCommand.hpp"

#include <iostream>

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"

namespace App
{
    // Reports the largest exactly representable power first, then falls back to a
    // scientific approximation only when the exact answer no longer fits.
    void runIntegerPower()
    {
        NoLib::ULong base_ULong_Var = 0;
        NoLib::ULong exponent_ULong_Var = 0;

        if (!readUnsignedPrompt("Unsigned base: ", base_ULong_Var) || !readUnsignedPrompt("Unsigned exponent: ", exponent_ULong_Var))
        {
            return;
        }

        if (base_ULong_Var == 0 && exponent_ULong_Var == 0)
        {
            printError("0^0 is undefined in this project.");
            return;
        }

        NoLib::ULong exactResult_ULong_Var = 0;
        NoLib::ULong exactExponent_ULong_Var = 0;
        NoLib::largestExactPower(base_ULong_Var, exponent_ULong_Var, exactResult_ULong_Var, exactExponent_ULong_Var);

        std::cout << "Largest exact power that fits:\n";
        std::cout << base_ULong_Var << " ^ " << exactExponent_ULong_Var << " = " << exactResult_ULong_Var << '\n';

        if (exactExponent_ULong_Var == exponent_ULong_Var)
        {
            std::cout << "Exact final result: " << exactResult_ULong_Var << '\n';
            return;
        }

        NoLib::ScientificNumber result_Scientific_Var;

        if (!NoLib::scientificPower(base_ULong_Var, exponent_ULong_Var, result_Scientific_Var))
        {
            printError("The decimal exponent exceeded unsigned storage.");
            return;
        }

        printScientificResult("Approximate final result: ", result_Scientific_Var);
    }
}
