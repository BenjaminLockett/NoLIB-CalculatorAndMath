#include "App/Commands/PolynomialCalculusCommand.hpp"

#include <iostream>

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "App/PolynomialInput.hpp"
#include "NoLib/Numerical/Differentiation.hpp"
#include "NoLib/Polynomial/PolynomialCalculus.hpp"

namespace App
{
    // The degree is capped one below the build maximum so the antiderivative still fits.
    void runPolynomialCalculus()
    {
        NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var> polynomial_Polynomial_Var;

        if (!readPolynomial(polynomial_Polynomial_Var, MaximumPolynomialDegree_UInt_Var - 1))
        {
            return;
        }

        NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var> derivative_Polynomial_Var;
        NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var> integral_Polynomial_Var;
        NoLib::differentiatePolynomial<MaximumPolynomialDegree_UInt_Var>(polynomial_Polynomial_Var, derivative_Polynomial_Var);
        NoLib::integratePolynomial<MaximumPolynomialDegree_UInt_Var>(polynomial_Polynomial_Var, 0.0L, integral_Polynomial_Var);

        std::cout << "Derivative coefficients:\n";
        printPolynomial(derivative_Polynomial_Var);
        std::cout << "Antiderivative coefficients, C = 0:\n";
        printPolynomial(integral_Polynomial_Var);

        NoLib::Real x_Real_Var = 0.0L;

        if (!readRealPrompt("Check the derivative at x = ", x_Real_Var))
        {
            return;
        }

        auto polynomialFunction_Function_Var = [&polynomial_Polynomial_Var](NoLib::Real input_Real_Var)
        {
            return NoLib::evaluatePolynomial<MaximumPolynomialDegree_UInt_Var>(polynomial_Polynomial_Var, input_Real_Var);
        };

        printRealResult("Symbolic polynomial derivative: ", NoLib::evaluatePolynomial<MaximumPolynomialDegree_UInt_Var>(derivative_Polynomial_Var, x_Real_Var), ComplexDecimals_UInt_Var);
        printRealResult("Centred-difference check: ", NoLib::derivativeAt(polynomialFunction_Function_Var, x_Real_Var), ComplexDecimals_UInt_Var);
    }
}
