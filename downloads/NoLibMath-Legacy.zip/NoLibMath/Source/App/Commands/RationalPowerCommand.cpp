#include "App/Commands/RationalPowerCommand.hpp"

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "NoLib/Scalar/Powers.hpp"

namespace App
{
    // A rational exponent keeps negative bases usable when the reduced denominator is odd.
    void runRationalPower()
    {
        NoLib::Real base_Real_Var = 0.0L;
        NoLib::SLong numerator_SLong_Var = 0;
        NoLib::ULong denominator_ULong_Var = 0;

        if (!readRealPrompt("Real base: ", base_Real_Var) || !readSignedPrompt("Exponent numerator: ", numerator_SLong_Var) || !readUnsignedPrompt("Exponent denominator: ", denominator_ULong_Var))
        {
            return;
        }

        NoLib::Real result_Real_Var = 0.0L;

        if (!NoLib::rationalPower(base_Real_Var, numerator_SLong_Var, denominator_ULong_Var, result_Real_Var))
        {
            printError("That rational power has no real result.");
            return;
        }

        printRealResult("Approximate rational-power result: ", result_Real_Var, ResultDecimals_UInt_Var);
    }
}
