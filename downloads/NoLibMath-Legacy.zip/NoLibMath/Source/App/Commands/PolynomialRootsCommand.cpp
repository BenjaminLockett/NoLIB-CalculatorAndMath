#include "App/Commands/PolynomialRootsCommand.hpp"

#include <iostream>

#include "App/PolynomialInput.hpp"
#include "NoLib/Complex/ComplexFormatting.hpp"
#include "NoLib/Polynomial/PolynomialRoots.hpp"
#include "NoLib/Text/StringStreamAdapters.hpp"

namespace App
{
    // The solver reports whether it converged, so unverified approximations are
    // labelled as such rather than presented as exact roots.
    void runPolynomialRoots()
    {
        NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var> polynomial_Polynomial_Var;

        if (!readPolynomial(polynomial_Polynomial_Var, MaximumPolynomialDegree_UInt_Var))
        {
            return;
        }

        NoLib::ComplexNumber roots_ComplexArray_Var[MaximumPolynomialDegree_UInt_Var];
        NoLib::UInt usedIterations_UInt_Var = 0;
        bool converged_Bool_Var = NoLib::findPolynomialRoots<MaximumPolynomialDegree_UInt_Var>(polynomial_Polynomial_Var, roots_ComplexArray_Var, usedIterations_UInt_Var);

        std::cout << (converged_Bool_Var ? "Roots converged in " : "Best approximations after ") << usedIterations_UInt_Var << " iterations:\n";

        for (NoLib::UInt index_UInt_Var = 0; index_UInt_Var < polynomial_Polynomial_Var.degree_UInt_Var; ++index_UInt_Var)
        {
            std::cout << "Root " << index_UInt_Var + 1 << ": " << NoLib::complexToString(roots_ComplexArray_Var[index_UInt_Var], RootDecimals_UInt_Var) << '\n';
        }
    }
}
