#include "App/PolynomialInput.hpp"

#include <iostream>

#include "App/ConsoleInput.hpp"
#include "App/ConsoleOutput.hpp"
#include "NoLib/Text/StringStreamAdapters.hpp"
#include "NoLib/Text/NumberParsing.hpp"

namespace App
{
    // The leading coefficient must be non-zero, otherwise the stated degree is a lie
    // and the root solver would divide by zero.
    bool readPolynomial(NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var>& polynomial_Polynomial_Var, NoLib::UInt maximumDegree_UInt_Var)
    {
        NoLib::ULong degree_ULong_Var = 0;

        if (!readUnsignedPrompt("Polynomial degree: ", degree_ULong_Var) || degree_ULong_Var > maximumDegree_UInt_Var)
        {
            printError("Degree is outside this build's range.");
            return false;
        }

        polynomial_Polynomial_Var = NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var>();
        polynomial_Polynomial_Var.degree_UInt_Var = static_cast<NoLib::UInt>(degree_ULong_Var);

        std::cout << "Enter coefficients from the constant term upward.\n";
        std::cout << "For 2x^3 - x + 4, enter 4, -1, 0, 2.\n";

        for (NoLib::UInt index_UInt_Var = 0; index_UInt_Var <= polynomial_Polynomial_Var.degree_UInt_Var; ++index_UInt_Var)
        {
            std::cout << "Coefficient of x^" << index_UInt_Var << ": ";
            NoLib::String coefficient_String_Var;
            std::cin >> coefficient_String_Var;

            if (!NoLib::readReal(coefficient_String_Var, polynomial_Polynomial_Var.coefficients_RealArray_Var[index_UInt_Var]))
            {
                printError("Invalid coefficient.");
                return false;
            }
        }

        if (polynomial_Polynomial_Var.coefficients_RealArray_Var[polynomial_Polynomial_Var.degree_UInt_Var] == 0.0L)
        {
            printError("The highest-degree coefficient cannot be zero.");
            return false;
        }

        return true;
    }
}
