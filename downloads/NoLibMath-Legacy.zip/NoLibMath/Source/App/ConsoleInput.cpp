#include "App/ConsoleInput.hpp"

#include <iostream>

#include "NoLib/Text/StringStreamAdapters.hpp"
#include "NoLib/Text/NumberParsing.hpp"

namespace App
{
    bool readUnsignedPrompt(const char* prompt_CharPtr_Var, NoLib::ULong& value_ULong_Var)
    {
        NoLib::String text_String_Var;
        std::cout << prompt_CharPtr_Var;
        std::cin >> text_String_Var;

        if (!NoLib::readUnsigned(text_String_Var, value_ULong_Var))
        {
            std::cout << "Invalid unsigned integer.\n";
            return false;
        }

        return true;
    }

    bool readSignedPrompt(const char* prompt_CharPtr_Var, NoLib::SLong& value_SLong_Var)
    {
        NoLib::String text_String_Var;
        std::cout << prompt_CharPtr_Var;
        std::cin >> text_String_Var;

        if (!NoLib::readSigned(text_String_Var, value_SLong_Var))
        {
            std::cout << "Invalid signed integer.\n";
            return false;
        }

        return true;
    }

    bool readRealPrompt(const char* prompt_CharPtr_Var, NoLib::Real& value_Real_Var)
    {
        NoLib::String text_String_Var;
        std::cout << prompt_CharPtr_Var;
        std::cin >> text_String_Var;

        if (!NoLib::readReal(text_String_Var, value_Real_Var))
        {
            std::cout << "Invalid real number.\n";
            return false;
        }

        return true;
    }
}
