#include "App/Menu.hpp"

#include <iostream>

#include "App/ConsoleOutput.hpp"
#include "App/Commands/ComplexPowerCommand.hpp"
#include "App/Commands/DecimalPowerCommand.hpp"
#include "App/Commands/IntegerPowerCommand.hpp"
#include "App/Commands/OdeCommand.hpp"
#include "App/Commands/PiCommand.hpp"
#include "App/Commands/PolynomialCalculusCommand.hpp"
#include "App/Commands/PolynomialRootsCommand.hpp"
#include "App/Commands/RationalPowerCommand.hpp"
#include "App/Commands/RootCommand.hpp"

namespace App
{
    namespace
    {
        // Option numbers are part of the user-facing contract and must not be reordered.
        const MenuEntry MenuEntries_MenuEntryArray_Var[] =
        {
            { 1, "Unsigned integer power", runIntegerPower },
            { 2, "Decimal/non-integer power", runDecimalPower },
            { 3, "Square, cube, or nth root", runRoot },
            { 4, "Complex power", runComplexPower },
            { 5, "Polynomial roots, degree 1-16", runPolynomialRoots },
            { 6, "Polynomial derivative and integral", runPolynomialCalculus },
            { 7, "Euler differential-equation stepper", runOde },
            { 8, "Pi approximation", runPi },
            { 9, "Rational power, including negative bases", runRationalPower },
            { 0, "Exit", nullptr }
        };

        const NoLib::UInt MenuEntryCount_UInt_Var = sizeof(MenuEntries_MenuEntryArray_Var) / sizeof(MenuEntries_MenuEntryArray_Var[0]);
    }

    void showMenu()
    {
        std::cout << "\nNoLib Mathematics\n";

        for (NoLib::UInt index_UInt_Var = 0; index_UInt_Var < MenuEntryCount_UInt_Var; ++index_UInt_Var)
        {
            std::cout << MenuEntries_MenuEntryArray_Var[index_UInt_Var].option_ULong_Var << ". " << MenuEntries_MenuEntryArray_Var[index_UInt_Var].description_CharPtr_Var << '\n';
        }
    }

    bool dispatchMenuChoice(NoLib::ULong choice_ULong_Var)
    {
        for (NoLib::UInt index_UInt_Var = 0; index_UInt_Var < MenuEntryCount_UInt_Var; ++index_UInt_Var)
        {
            if (MenuEntries_MenuEntryArray_Var[index_UInt_Var].option_ULong_Var != choice_ULong_Var)
            {
                continue;
            }

            if (MenuEntries_MenuEntryArray_Var[index_UInt_Var].action_FunctionPtr_Var == nullptr)
            {
                return false;
            }

            MenuEntries_MenuEntryArray_Var[index_UInt_Var].action_FunctionPtr_Var();
            return true;
        }

        printError("Unknown option.");
        return true;
    }
}
