#!/bin/sh
# Single-command GCC/Clang build, no CMake required.
set -e
g++ -std=c++17 -Wall -Wextra -Wpedantic -Wshadow -IInclude \
    main.cpp $(find Source -name '*.cpp') -o NoLibMath
echo "built ./NoLibMath"
