#include <iostream>

#include "App/ConsoleInput.hpp"
#include "App/Menu.hpp"
#include "NoLib/Core/Types.hpp"

// Startup and dispatch only. Every calculation lives in App/Commands.
int main()
{
    std::cout.precision(18);

    while (true)
    {
        App::showMenu();

        NoLib::ULong choice_ULong_Var = 0;

        if (!App::readUnsignedPrompt("Choice: ", choice_ULong_Var))
        {
            continue;
        }

        if (!App::dispatchMenuChoice(choice_ULong_Var))
        {
            return 0;
        }
    }
}
