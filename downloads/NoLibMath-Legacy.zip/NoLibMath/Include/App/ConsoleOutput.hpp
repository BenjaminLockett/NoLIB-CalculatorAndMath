#pragma once

// Display helpers. Formatting decisions live here so the commands stay short.

#include "App/AppConfig.hpp"
#include "NoLib/Core/Types.hpp"
#include "NoLib/Scalar/ScientificNumber.hpp"
#include "NoLib/Polynomial/Polynomial.hpp"
#include "NoLib/Text/RealFormatting.hpp"

namespace App
{
    void printError(const char* message_CharPtr_Var);
    void printRealResult(const char* label_CharPtr_Var, NoLib::Real value_Real_Var, NoLib::UInt decimals_UInt_Var);
    void printScientificResult(const char* label_CharPtr_Var, const NoLib::ScientificNumber& value_Scientific_Var);
    void printPolynomial(const NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var>& polynomial_Polynomial_Var);
}
