#pragma once

// Typed console prompts. Every prompt reports failure instead of guessing a value.

#include "NoLib/Core/Types.hpp"

namespace App
{
    bool readUnsignedPrompt(const char* prompt_CharPtr_Var, NoLib::ULong& value_ULong_Var);
    bool readSignedPrompt(const char* prompt_CharPtr_Var, NoLib::SLong& value_SLong_Var);
    bool readRealPrompt(const char* prompt_CharPtr_Var, NoLib::Real& value_Real_Var);
}
