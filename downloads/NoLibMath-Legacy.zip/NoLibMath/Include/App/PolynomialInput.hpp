#pragma once

// Reads a polynomial from the console and enforces the degree invariant.

#include "App/AppConfig.hpp"
#include "NoLib/Polynomial/Polynomial.hpp"

namespace App
{
    bool readPolynomial(NoLib::Polynomial<MaximumPolynomialDegree_UInt_Var>& polynomial_Polynomial_Var, NoLib::UInt maximumDegree_UInt_Var);
}
