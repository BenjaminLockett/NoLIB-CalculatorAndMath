#pragma once

// Menu command: PolynomialCalculus.

namespace App
{
    void runPolynomialCalculus();
}
