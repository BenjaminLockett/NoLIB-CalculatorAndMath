#pragma once

// Menu command: Root.

namespace App
{
    void runRoot();
}
