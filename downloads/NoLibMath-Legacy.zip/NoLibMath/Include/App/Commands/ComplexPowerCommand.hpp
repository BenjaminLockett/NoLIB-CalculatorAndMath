#pragma once

// Menu command: ComplexPower.

namespace App
{
    void runComplexPower();
}
