#pragma once

// Menu command: Pi.

namespace App
{
    void runPi();
}
