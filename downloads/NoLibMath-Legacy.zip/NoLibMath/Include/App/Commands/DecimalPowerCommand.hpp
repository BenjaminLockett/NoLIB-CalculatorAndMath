#pragma once

// Menu command: DecimalPower.

namespace App
{
    void runDecimalPower();
}
