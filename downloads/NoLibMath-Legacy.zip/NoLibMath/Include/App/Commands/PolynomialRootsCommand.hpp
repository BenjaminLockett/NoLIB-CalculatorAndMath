#pragma once

// Menu command: PolynomialRoots.

namespace App
{
    void runPolynomialRoots();
}
