#pragma once

// Menu command: IntegerPower.

namespace App
{
    void runIntegerPower();
}
