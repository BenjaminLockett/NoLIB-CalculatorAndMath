#pragma once

// Menu command: RationalPower.

namespace App
{
    void runRationalPower();
}
