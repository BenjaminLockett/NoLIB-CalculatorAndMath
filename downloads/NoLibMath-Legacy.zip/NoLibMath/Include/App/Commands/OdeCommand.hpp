#pragma once

// Menu command: Ode.

namespace App
{
    void runOde();
}
