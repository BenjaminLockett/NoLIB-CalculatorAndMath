#pragma once

// Menu data and dispatch. Adding a command means adding one table row here
// and one file under App/Commands.

#include "NoLib/Core/Types.hpp"

namespace App
{
    // A single menu row. The action is null for the exit row.
    struct MenuEntry
    {
        NoLib::ULong option_ULong_Var;
        const char* description_CharPtr_Var;
        void (*action_FunctionPtr_Var)();
    };

    void showMenu();

    // Returns false when the chosen option asks the program to stop.
    bool dispatchMenuChoice(NoLib::ULong choice_ULong_Var);
}
