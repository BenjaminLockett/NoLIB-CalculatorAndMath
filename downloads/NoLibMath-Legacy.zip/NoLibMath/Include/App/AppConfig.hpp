#pragma once

// Fixed capacities and display widths used by the console application.

#include "NoLib/Core/Types.hpp"

namespace App
{
    // Highest polynomial degree the menu will accept.
    constexpr NoLib::UInt MaximumPolynomialDegree_UInt_Var = 16;

    // Upper bound on Euler steps, chosen so a mistyped value cannot hang the program.
    constexpr NoLib::ULong MaximumEulerSteps_ULong_Var = 100000000ULL;

    // Decimal places used for the different classes of result.
    constexpr NoLib::UInt CoefficientDecimals_UInt_Var = 8;
    constexpr NoLib::UInt RootDecimals_UInt_Var = 14;
    constexpr NoLib::UInt ComplexDecimals_UInt_Var = 16;
    constexpr NoLib::UInt ResultDecimals_UInt_Var = 18;
    constexpr NoLib::UInt ConstantDecimals_UInt_Var = 20;
}
